<template>
  <div>
    <div style="height:2px;">
    </div>
    <!-- 内容部分 -->
    <el-card class="box-card" >
      <el-row>
        <el-col :span="24">
          组员: 张裕人&nbsp;&nbsp;何理扬&nbsp;&nbsp;于颖奇
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          email: 596136894@qq.com
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <a href="https://github.com/CGYR/HLY2B3B">github地址</a>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
    export default {
        name: ""
    }
</script>

<style scoped>

</style>
