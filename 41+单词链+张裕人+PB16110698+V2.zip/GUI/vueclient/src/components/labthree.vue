<template>
  <div>
    <div style="height:2px;">
    </div>
    <!-- 内容部分 -->
    <el-card class="box-card" >
      <el-row>
        <el-col :span="24">
          实验三暂未布置
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
    export default {
        name: ""
    }
</script>

<style scoped>

</style>
