<template>
  <div>
    <div style="height:2px;">
    </div>
    <el-card class="box-card" >
      <el-row>
        <el-col :span="24">
          这是一个中国科学技术大学2019年春季学期的软件工程网站，目前完成的实验有:
        </el-col>
      </el-row>
    </el-card>
    <el-card class="box-card" >
      <el-row>
        <el-col :span="24">
          <span style="font-size:18px"><b>实验一</b></span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          寻找最长单词链,已经完成了以下需求

        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span style="color:orangered">-w</span> 参数完成度: <span style="color:orangered">100%</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span style="color:orangered">-c</span> 参数完成度: <span style="color:orangered">100%</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span style="color:orangered">-t -h</span> 参数完成度: <span style="color:orangered">100%</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span style="color:orangered">-n</span> 参数完成度: <span style="color:orangered">100%</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span style="color:blue">GUI</span> 完成度: <span style="color:orangered">100%</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span style="color:blue">错误处理</span> 完成度: <span style="color:gray">除了完成实验要求上的几个要求
        外，还添加好几个报错情况，具体请看实验报告</span>
        </el-col>
      </el-row>
    </el-card>
    <el-card class="box-card" >
      <el-row>
        <el-col :span="24">
          <span style="font-size:18px"><b>实验二</b></span>
        </el-col>
      </el-row>
    </el-card>
    <el-card class="box-card" >
      <el-row>
        <el-col :span="24">
          <span style="font-size:18px"><b>实验三</b></span>
        </el-col>
      </el-row>
    </el-card>
  </div>
</template>

<script>
    export default {
        name: ""
    }
</script>

<style scoped>

</style>
